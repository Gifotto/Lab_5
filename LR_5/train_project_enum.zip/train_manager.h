#pragma once
#include <string>
#include <map>
#include <vector>
#include "train.h"

using namespace std;

// Класс для управления всеми поездами
class TrainManager {
public:
    TrainManager(int min_stops = 2); // Конструктор с минимальным числом остановок

    void AddTrain(const string& name, const vector<string>& towns); // Добавить поезд
    vector<string> GetTrainsForTown(const string& town) const; // Поезда, проходящие через город
    vector<string> GetTownsForTrain(const string& train) const; // Города, которые посещает поезд
    vector<string> GetAllTrains() const; // Все поезда

private:
    map<string, Train> trains;         // Карта имя поезда → объект Train
    map<string, vector<string>> town_to_trains; // Карта город → список поездов
    int min_stops;                     // Минимально допустимое число остановок для создания поезда
};