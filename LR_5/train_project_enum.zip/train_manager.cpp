#include "train_manager.h"

// Конструктор инициализирует минимальное число остановок
TrainManager::TrainManager(int min_stops) : min_stops(min_stops) {}

// Добавить поезд, если он содержит достаточное число остановок
void TrainManager::AddTrain(const string& name, const vector<string>& towns) {
    if (towns.size() < static_cast<size_t>(min_stops)) return;
    trains[name] = Train(name, towns);
    for (const string& town : towns) {
        town_to_trains[town].push_back(name);
    }
}

// Получить список поездов, проходящих через указанный город
vector<string> TrainManager::GetTrainsForTown(const string& town) const {
    if (town_to_trains.count(town)) return town_to_trains.at(town);
    return {};
}

// Получить список городов маршрута поезда
vector<string> TrainManager::GetTownsForTrain(const string& train) const {
    if (trains.count(train)) return trains.at(train).GetTowns();
    return {};
}

// Получить список всех поездов
vector<string> TrainManager::GetAllTrains() const {
    vector<string> result;
    for (const auto& [name, _] : trains) {
        result.push_back(name);
    }
    return result;
}