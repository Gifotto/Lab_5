#pragma once
#include <string>
#include "train_manager.h"

using namespace std;

// Обрабатывает строку команды и вызывает нужную функцию менеджера
void ProcessCommand(const string& line, TrainManager& manager);