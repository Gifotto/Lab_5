#include <iostream>
#include <string>
#include <cstdlib>
#include "train_manager.h"
#include "commands.h"

using namespace std;

// Функция печати доступного меню команд
void PrintMenu() {
    cout << "\n--- Train Manager Menu ---\n";
    cout << "Available commands:\n";
    cout << "  CREATE_TRAIN <name> <town1> <town2> ... <townN>\n";
    cout << "  TRAINS_FOR_TOWN <town>\n";
    cout << "  TOWNS_FOR_TRAIN <train>\n";
    cout << "  TRAINS\n";
    cout << "  EXIT\n";
    cout << "----------------------------\n";
}

int main(int argc, char* argv[]) {
    // Установка минимального количества остановок, по умолчанию 2
    int min_stops = 2;
    if (argc > 1) {
        min_stops = atoi(argv[1]);
        if (min_stops < 1) min_stops = 2;
    }

    // Инициализация менеджера поездов
    TrainManager manager(min_stops);

    // Печать меню
    PrintMenu();

    // Добавление предустановленных поездов (пример)
    ProcessCommand("CREATE_TRAIN Sapsan Moscow Tver Saint-Petersburg", manager);
    ProcessCommand("CREATE_TRAIN Lastochka Moscow Vladimir Nizhny-Novgorod", manager);
    ProcessCommand("CREATE_TRAIN NevskyEkspress Saint-Petersburg Tver Moscow", manager);
    ProcessCommand("CREATE_TRAIN UralExpress Yekaterinburg Perm Kazan", manager);
    ProcessCommand("CREATE_TRAIN VolgaTrain Nizhny-Novgorod Kazan Samara", manager);
    ProcessCommand("CREATE_TRAIN BaikalExpress Irkutsk Ulan-Ude Chita", manager);
    ProcessCommand("CREATE_TRAIN KubanLine Krasnodar Rostov Voronezh", manager);
    ProcessCommand("CREATE_TRAIN NorthStar Murmansk Petrozavodsk Saint-Petersburg", manager);
    ProcessCommand("CREATE_TRAIN SteppeWind Orenburg Samara Saratov Volgograd", manager);
    ProcessCommand("CREATE_TRAIN AmberKaliningrad Kaliningrad Gdansk Warsaw", manager);

    string line;
    // Основной цикл ввода команд от пользователя
    while (true) {
        cout << "\nEnter command: ";
        if (!getline(cin, line) || line == "EXIT") break;
        if (line.empty()) continue;
        ProcessCommand(line, manager);  // Обработка команды
    }

    return 0;
}