#include "commands.h"
#include <sstream>
#include <iostream>

using namespace std;

// Разбор строки команды и выполнение соответствующего действия
void ProcessCommand(const string& line, TrainManager& manager) {
    istringstream iss(line);
    string command;
    iss >> command;

    if (command == "CREATE_TRAIN") {
        string name, town;
        iss >> name;
        vector<string> towns;
        while (iss >> town) towns.push_back(town);
        manager.AddTrain(name, towns);
    }
    else if (command == "TRAINS_FOR_TOWN") {
        string town;
        iss >> town;
        vector<string> trains = manager.GetTrainsForTown(town);
        cout << "Trains for " << town << ": ";
        for (const string& train : trains) cout << train << " ";
        cout << endl;
    }
    else if (command == "TOWNS_FOR_TRAIN") {
        string train;
        iss >> train;
        vector<string> towns = manager.GetTownsForTrain(train);
        cout << "Towns for " << train << ": ";
        for (const string& town : towns) cout << town << " ";
        cout << endl;
    }
    else if (command == "TRAINS") {
        vector<string> trains = manager.GetAllTrains();
        cout << "All trains: ";
        for (const string& train : trains) cout << train << " ";
        cout << endl;
    }
    else {
        cout << "Unknown command!" << endl;
    }
}