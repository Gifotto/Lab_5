#pragma once
#include <string>
#include <vector>

using namespace std;

// Класс Train представляет один поезд с именем и маршрутом
class Train {
public:
    Train(); // Конструктор по умолчанию
    Train(const string& name, const vector<string>& towns); // Конструктор с параметрами

    string GetName() const;              // Получить имя поезда
    const vector<string>& GetTowns() const; // Получить список городов (маршрут)

private:
    string name;              // Название поезда
    vector<string> towns;     // Список городов в маршруте
};