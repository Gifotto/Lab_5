#include "train.h"

// Конструктор по умолчанию
Train::Train() : name(""), towns() {}

// Конструктор с инициализацией
Train::Train(const string& name, const vector<string>& towns)
    : name(name), towns(towns) {}

// Получить имя поезда
string Train::GetName() const {
    return name;
}

// Получить маршрут поезда
const vector<string>& Train::GetTowns() const {
    return towns;
}